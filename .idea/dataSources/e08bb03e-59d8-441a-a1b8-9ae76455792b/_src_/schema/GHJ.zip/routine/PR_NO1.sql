CREATE procedure pr_NO1(aname varchar2 ,areaid number,operatorid number)
is
begin
   insert into t_address values(seq_adress.nextval,aname,areaid,operatorid);
end;
/
