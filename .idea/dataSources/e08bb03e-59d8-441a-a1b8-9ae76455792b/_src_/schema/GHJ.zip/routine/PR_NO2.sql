CREATE procedure pr_NO2(T_ID number,T_NAME out varchar2)--在这里使用out关键字设置传出参数
is
begin
  SELECT name into T_NAME from T_ADDRESS where id=T_ID;
end;
/
