CREATE TRIGGER TG_LK
AFTER INSERT
  ON T_ADDRESS
FOR EACH ROW
  declare
begin
  dbms_output.put_line('操作成功');
end;
/
